
package de.svjatoslav.rechnungstempel

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.LayoutInflater
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {
    private lateinit var etKreditor: EditText
    private lateinit var etKreditorNr: EditText
    private lateinit var etProjektName: EditText
    private lateinit var etProjektNummer: EditText
    private lateinit var etTemplate: EditText
    private lateinit var etFontSize: EditText
    private lateinit var cbWhiteBg: CheckBox
    private lateinit var cbOnlyFirst: CheckBox
    private lateinit var cbApplyAll: CheckBox
    private lateinit var btnPickPdf: Button
    private lateinit var btnPickOutput: Button
    private lateinit var btnStamp: Button
    private lateinit var btnSearch: Button
    private lateinit var btnLoadCsv: Button
    private lateinit var rgMode: RadioGroup
    private lateinit var rbCorners: RadioButton
    private lateinit var rbManual: RadioButton
    private lateinit var btnPickPosition: Button
    private lateinit var spCorner: Spinner
    private lateinit var etMargin: EditText
    private lateinit var llCorners: LinearLayout

    private var inputUri: Uri? = null
    private var outputUri: Uri? = null

    // manual selection
    private var selPageIndex: Int? = null
    private var selXpt: Float? = null
    private var selYpt: Float? = null

    private val dataStore = DataStore()

    private val pickPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            inputUri = uri
        }
    }

    private val pickCsv = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            contentResolver.openInputStream(uri)?.use { ins ->
                dataStore.loadCsv(BufferedReader(InputStreamReader(ins)))
                Toast.makeText(this, "CSV geladen (${dataStore.rows.size} Zeilen)", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val createOutput = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) {
            outputUri = uri
        }
    }

    private val pickPosition = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK && res.data != null) {
            selPageIndex = res.data!!.getIntExtra("pageIndex", 0)
            selXpt = res.data!!.getFloatExtra("xpt", -1f)
            selYpt = res.data!!.getFloatExtra("ypt", -1f)
            Toast.makeText(this, "Position gesetzt: Seite ${selPageIndex!!+1}, x=${"%.1f".format(selXpt)}, y=${"%.1f".format(selYpt)} pt", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etKreditor = findViewById(R.id.etKreditor)
        etKreditorNr = findViewById(R.id.etKreditorNr)
        etProjektName = findViewById(R.id.etProjektName)
        etProjektNummer = findViewById(R.id.etProjektNummer)
        etTemplate = findViewById(R.id.etTemplate)
        etFontSize = findViewById(R.id.etFontSize)
        cbWhiteBg = findViewById(R.id.cbWhiteBg)
        cbOnlyFirst = findViewById(R.id.cbOnlyFirst)
        cbApplyAll = findViewById(R.id.cbApplyAll)
        btnPickPdf = findViewById(R.id.btnPickPdf)
        btnPickOutput = findViewById(R.id.btnPickOutput)
        btnStamp = findViewById(R.id.btnStamp)
        btnSearch = findViewById(R.id.btnSearch)
        btnLoadCsv = findViewById(R.id.btnLoadCsv)
        rgMode = findViewById(R.id.rgMode)
        rbCorners = findViewById(R.id.rbCorners)
        rbManual = findViewById(R.id.rbManual)
        btnPickPosition = findViewById(R.id.btnPickPosition)
        spCorner = findViewById(R.id.spCorner)
        etMargin = findViewById(R.id.etMargin)
        llCorners = findViewById(R.id.llCorners)

        // Default CSV from assets
        assets.open("stammdaten.csv").use { ins ->
            dataStore.loadCsv(BufferedReader(InputStreamReader(ins)))
        }

        spCorner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Oben rechts", "Oben links", "Unten rechts", "Unten links"))

        rgMode.setOnCheckedChangeListener { _, checkedId ->
            val manual = checkedId == R.id.rbManual
            btnPickPosition.isEnabled = manual
            llCorners.isEnabled = !manual
            for (i in 0 until llCorners.childCount) llCorners.getChildAt(i).isEnabled = !manual
        }

        btnLoadCsv.setOnClickListener { pickCsv.launch(arrayOf("text/*", "text/csv", "application/vnd.ms-excel")) }
        btnSearch.setOnClickListener { openSearchDialog() }
        btnPickPdf.setOnClickListener { pickPdf.launch(arrayOf("application/pdf")) }
        btnPickOutput.setOnClickListener { createOutput.launch("gestempelt.pdf") }
        btnPickPosition.setOnClickListener {
            val inUri = inputUri ?: return@setOnClickListener Toast.makeText(this, "Bitte PDF wählen", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, PositionPickerActivity::class.java)
            intent.data = inUri
            intent.putExtra("template", renderTemplate())
            intent.putExtra("fontSize", etFontSize.text.toString().toFloatOrNull() ?: 10f)
            pickPosition.launch(intent)
        }
        btnStamp.setOnClickListener { doStamp() }
    }

    private fun openSearchDialog() {
        val view = LayoutInflater.from(this).inflate(android.R.layout.list_content, null)
        val rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this)
        val adapter = DataAdapter(dataStore.rows) { row ->
            etKreditor.setText(row.kreditorName)
            etKreditorNr.setText(row.kreditorNr)
            etProjektName.setText(row.projektName)
            etProjektNummer.setText(row.projektNummer)
        }
        rv.adapter = adapter

        val filterEdit = EditText(this)
        filterEdit.hint = "Filter (Kreditor/Projekt/Nummer)"
        filterEdit.addTextChangedListener(SimpleTextWatcher { q -> adapter.filter(q) })

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24,16,24,0)
            addView(filterEdit)
            addView(rv)
        }

        AlertDialog.Builder(this)
            .setTitle("Kreditor/Projekt suchen")
            .setView(container)
            .setPositiveButton("Schließen", null)
            .show()
    }

    private fun renderTemplate(): String {
        val ctx = mapOf(
            "kreditor" to etKreditor.text.toString(),
            "kreditor_nr" to etKreditorNr.text.toString(),
            "projekt_name" to etProjektName.text.toString(),
            "projektnummer" to etProjektNummer.text.toString(),
            "date" to SimpleDateFormat("yyyy-MM-dd").format(Date())
        )
        var out = etTemplate.text.toString()
        ctx.forEach { (k,v) -> out = out.replace("{$k}", v ?: "") }
        return out
    }

    private fun doStamp() {
        val inUri = inputUri ?: return Toast.makeText(this, "Bitte Eingabe-PDF wählen", Toast.LENGTH_SHORT).show()
        val outUri = outputUri ?: return Toast.makeText(this, "Bitte Ausgabe-Datei wählen", Toast.LENGTH_SHORT).show()
        val text = renderTemplate()
        val fontSize = etFontSize.text.toString().toFloatOrNull() ?: 10f
        val whiteBg = cbWhiteBg.isChecked
        val onlyFirst = cbOnlyFirst.isChecked

        try {
            if (rbManual.isChecked) {
                val page = selPageIndex ?: return Toast.makeText(this, "Bitte Position wählen…", Toast.LENGTH_SHORT).show()
                val x = selXpt ?: return Toast.makeText(this, "Bitte Position wählen…", Toast.LENGTH_SHORT).show()
                val y = selYpt ?: return Toast.makeText(this, "Bitte Position wählen…", Toast.LENGTH_SHORT).show()
                val applyAll = cbApplyAll.isChecked
                PdfStamper.stampAt(this, inUri, outUri, text, fontSize, page, x, y, applyAll, whiteBg)
            } else {
                val margin = etMargin.text.toString().toFloatOrNull() ?: 20f
                val corner = when (spCorner.selectedItemPosition) {
                    0 -> PdfStamper.Position.TOP_RIGHT
                    1 -> PdfStamper.Position.TOP_LEFT
                    2 -> PdfStamper.Position.BOTTOM_RIGHT
                    else -> PdfStamper.Position.BOTTOM_LEFT
                }
                PdfStamper.stampCorner(this, inUri, outUri, text, corner, margin, fontSize, onlyFirst, whiteBg)
            }
            Toast.makeText(this, "Gespeichert", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Fehler: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
