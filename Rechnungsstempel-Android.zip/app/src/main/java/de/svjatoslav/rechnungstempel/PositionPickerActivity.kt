
package de.svjatoslav.rechnungstempel

import android.app.Activity
import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.github.chrisbanes.photoview.OnPhotoTapListener
import com.github.chrisbanes.photoview.PhotoView
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.File
import java.io.FileOutputStream

class PositionPickerActivity : AppCompatActivity() {
    private lateinit var photoView: PhotoView
    private lateinit var spPage: Spinner
    private lateinit var btnOk: Button
    private lateinit var btnCancel: Button

    private var stampText: String = ""
    private var fontSize: Float = 10f

    private var pdfUri: Uri? = null
    private var tempFile: File? = null

    private var renderer: PdfRenderer? = null
    private var pageCount: Int = 0
    private var pageWidthPx: Int = 0
    private var pageHeightPx: Int = 0
    private var pageWidthPt: Float = 0f
    private var pageHeightPt: Float = 0f

    private var selXpt: Float = -1f
    private var selYpt: Float = -1f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_position_picker)

        photoView = findViewById(R.id.photoView)
        spPage = findViewById(R.id.spPage)
        btnOk = findViewById(R.id.btnOk)
        btnCancel = findViewById(R.id.btnCancel)

        pdfUri = intent.data
        stampText = intent.getStringExtra("template") ?: ""
        fontSize = intent.getFloatExtra("fontSize", 10f)

        if (pdfUri == null) { finish(); return }

        // Prepare temp file to access via PdfRenderer and pdfbox-android
        tempFile = copyUriToCache(pdfUri!!)

        openPdf(tempFile!!)

        btnCancel.setOnClickListener { setResult(Activity.RESULT_CANCELED); finish() }
        btnOk.setOnClickListener {
            if (selXpt < 0 || selYpt < 0) { Toast.makeText(this, "Bitte ins Dokument tippen", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val data = intent
            data.putExtra("pageIndex", spPage.selectedItemPosition)
            data.putExtra("xpt", selXpt)
            data.putExtra("ypt", selYpt)
            setResult(Activity.RESULT_OK, data)
            finish()
        }

        photoView.setOnPhotoTapListener(OnPhotoTapListener { view, x, y ->
            // x,y are relative (0..1) in the displayed drawable
            val px = x * pageWidthPx
            val py = y * pageHeightPx
            selXpt = (px / pageWidthPx) * pageWidthPt
            selYpt = pageHeightPt - (py / pageHeightPx) * pageHeightPt
            Toast.makeText(this, "x=${"%.1f".format(selXpt)} pt, y=${"%.1f".format(selYpt)} pt", Toast.LENGTH_SHORT).show()
            // Draw overlay by re-rendering page with marker
            renderPage(spPage.selectedItemPosition, showMarker = true)
        })
    }

    private fun copyUriToCache(uri: Uri): File {
        val outFile = File.createTempFile("pdfsrc", ".pdf", cacheDir)
        contentResolver.openInputStream(uri)?.use { ins ->
            FileOutputStream(outFile).use { outs -> ins.copyTo(outs) }
        }
        return outFile
    }

    private fun openPdf(file: File) {
        // PdfRenderer requires a ParcelFileDescriptor
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        renderer = PdfRenderer(pfd)
        pageCount = renderer!!.pageCount

        // Read page size in points via pdfbox-android
        PDFBoxResourceLoader.init(applicationContext)
        PDDocument.load(file).use { doc ->
            val first = doc.getPage(0)
            pageWidthPt = first.mediaBox.width
            pageHeightPt = first.mediaBox.height
        }

        val pages = (1..pageCount).map { "Seite $it" }
        spPage.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, pages)
        spPage.setSelection(0)
        (spPage.onItemSelectedListener as? AdapterView.OnItemSelectedListener)
        spPage.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                selXpt = -1f; selYpt = -1f
                renderPage(position, showMarker = false)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        renderPage(0, showMarker = false)
    }

    private fun renderPage(index: Int, showMarker: Boolean) {
        val page = renderer?.openPage(index) ?: return
        val screenW = resources.displayMetrics.widthPixels
        val ratio = page.height.toFloat() / page.width
        val bmpW = screenW
        val bmpH = (bmpW * ratio).toInt()
        val bitmap = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        page.close()
        pageWidthPx = bmpW
        pageHeightPx = bmpH

        if (showMarker && selXpt >= 0 && selYpt >= 0) {
            val canvas = android.graphics.Canvas(bitmap)
            val xPx = (selXpt / pageWidthPt) * pageWidthPx
            val yPx = (1f - (selYpt / pageHeightPt)) * pageHeightPx
            val p = Paint().apply { color = Color.RED; strokeWidth = 3f }
            canvas.drawCircle(xPx, yPx, 10f, p)
            canvas.drawLine(xPx-25, yPx, xPx+25, yPx, p)
            canvas.drawLine(xPx, yPx-25, xPx, yPx+25, p)
            val textPaint = Paint().apply { color = Color.BLACK; textSize = 16f; isFakeBoldText = true }
            canvas.drawText(stampText, xPx + 14f, yPx - 14f, textPaint)
        }

        photoView.setImageBitmap(bitmap)
    }

    override fun onDestroy() {
        renderer?.close()
        super.onDestroy()
    }
}
