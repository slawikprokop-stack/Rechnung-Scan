
package de.svjatoslav.rechnungstempel

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DataAdapter(private val original: List<DataRow>, private val onPick: (DataRow)->Unit): RecyclerView.Adapter<DataAdapter.VH>() {
    private val items = original.toMutableList()

    fun filter(q: String) {
        val qq = q.lowercase()
        items.clear()
        items.addAll(original.filter { it.kreditorName.lowercase().contains(qq) || it.kreditorNr.lowercase().contains(qq) || it.projektName.lowercase().contains(qq) || it.projektNummer.lowercase().contains(qq) })
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_2, parent, false)
        return VH(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val row = items[position]
        holder.t1.text = row.kreditorName + "  •  " + row.projektName
        holder.t2.text = "Nr: ${row.kreditorNr}   |   Projektnr: ${row.projektNummer}"
        holder.itemView.setOnClickListener { onPick(row) }
    }

    class VH(v: View): RecyclerView.ViewHolder(v) {
        val t1: TextView = v.findViewById(android.R.id.text1)
        val t2: TextView = v.findViewById(android.R.id.text2)
    }
}
