
package de.svjatoslav.rechnungstempel

import java.io.BufferedReader

data class DataRow(val kreditorName: String, val kreditorNr: String, val projektName: String, val projektNummer: String)

class DataStore {
    val rows = mutableListOf<DataRow>()

    fun loadCsv(br: BufferedReader) {
        rows.clear()
        val header = br.readLine() ?: return
        var line: String?
        while (true) {
            line = br.readLine() ?: break
            val parts = parseCsvLine(line!!)
            if (parts.size >= 4) {
                rows.add(DataRow(parts[0], parts[1], parts[2], parts[3]))
            }
        }
    }

    private fun parseCsvLine(line: String): List<String> {
        // Simple CSV split supporting quoted commas
        val out = mutableListOf<String>()
        var sb = StringBuilder()
        var inQuotes = false
        for (c in line) {
            when (c) {
                '"' -> { inQuotes = !inQuotes }
                ',' -> if (!inQuotes) { out.add(sb.toString()); sb = StringBuilder() } else sb.append(c)
                else -> sb.append(c)
            }
        }
        out.add(sb.toString())
        return out
    }
}
