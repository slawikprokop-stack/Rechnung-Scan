
package de.svjatoslav.rechnungstempel

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import java.io.File
import java.io.FileOutputStream

object PdfStamper {
    enum class Position { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }

    private fun Context.copyToFile(uri: Uri): File {
        val f = File.createTempFile("in", ".pdf", cacheDir)
        contentResolver.openInputStream(uri)?.use { ins -> FileOutputStream(f).use { outs -> ins.copyTo(outs) } }
        return f
    }

    private fun Context.writeToUri(doc: PDDocument, uri: Uri) {
        contentResolver.openOutputStream(uri)?.use { outs -> doc.save(outs) }
    }

    fun stampCorner(ctx: Context, inUri: Uri, outUri: Uri, text: String, position: Position, margin: Float, fontSize: Float, onlyFirstPage: Boolean, whiteBg: Boolean) {
        PDFBoxResourceLoader.init(ctx)
        val inFile = ctx.copyToFile(inUri)
        PDDocument.load(inFile).use { doc ->
            val font = PDType1Font.HELVETICA_BOLD
            val pageCount = doc.numberOfPages
            for (i in 0 until pageCount) {
                if (onlyFirstPage && i>0) break
                val page: PDPage = doc.getPage(i)
                val box: PDRectangle = page.mediaBox
                val pageW = box.width
                val pageH = box.height
                val textW = font.getStringWidth(text)/1000f * fontSize
                val textH = font.fontDescriptor.capHeight/1000f * fontSize
                val (x,y) = when(position) {
                    Position.TOP_LEFT -> Pair(margin, pageH - margin - textH)
                    Position.TOP_RIGHT -> Pair(pageW - margin - textW, pageH - margin - textH)
                    Position.BOTTOM_LEFT -> Pair(margin, margin)
                    Position.BOTTOM_RIGHT -> Pair(pageW - margin - textW, margin)
                }
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true).use { cs ->
                    if (whiteBg) {
                        val pad = 3f
                        cs.setNonStrokingColor(255)
                        cs.addRect(x - pad, y - pad, textW + 2*pad, textH + 2*pad)
                        cs.fill()
                        cs.setNonStrokingColor(0)
                    }
                    cs.beginText()
                    cs.setFont(font, fontSize)
                    cs.newLineAtOffset(x, y)
                    cs.showText(text)
                    cs.endText()
                }
            }
            ctx.writeToUri(doc, outUri)
        }
    }

    fun stampAt(ctx: Context, inUri: Uri, outUri: Uri, text: String, fontSize: Float, pageIndex: Int, x: Float, y: Float, applyAll: Boolean, whiteBg: Boolean) {
        PDFBoxResourceLoader.init(ctx)
        val inFile = ctx.copyToFile(inUri)
        PDDocument.load(inFile).use { doc ->
            val font = PDType1Font.HELVETICA_BOLD
            val start = if (applyAll) 0 else pageIndex
            val end = if (applyAll) doc.numberOfPages - 1 else pageIndex
            for (i in start..end) {
                val page: PDPage = doc.getPage(i)
                val textW = font.getStringWidth(text)/1000f * fontSize
                val textH = font.fontDescriptor.capHeight/1000f * fontSize
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true).use { cs ->
                    if (whiteBg) {
                        val pad = 3f
                        cs.setNonStrokingColor(255)
                        cs.addRect(x - pad, y - pad, textW + 2*pad, textH + 2*pad)
                        cs.fill()
                        cs.setNonStrokingColor(0)
                    }
                    cs.beginText()
                    cs.setFont(font, fontSize)
                    cs.newLineAtOffset(x, y)
                    cs.showText(text)
                    cs.endText()
                }
            }
            ctx.writeToUri(doc, outUri)
        }
    }
}
